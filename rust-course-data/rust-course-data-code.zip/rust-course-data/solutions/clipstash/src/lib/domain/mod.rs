//! Business-specific modules and functions

pub mod clip;
pub mod time;
pub mod maintenance;

pub use clip::Clip;