pub fn add(lhs: isize, rhs: isize) -> isize {
    lhs + rhs
}
pub fn sub(lhs: isize, rhs: isize) -> isize {
    lhs - rhs
}
pub fn mul(lhs: isize, rhs: isize) -> isize {
    lhs * rhs
}
