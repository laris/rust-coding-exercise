var N = null;var sourcesIndex = {};
sourcesIndex["new_channel"] = {"name":"","dirs":[{"name":"flavors","dirs":[],"files":["array.rs","list.rs","mod.rs","zero.rs"]}],"files":["channel.rs","counter.rs","err.rs","lib.rs","notify.rs","utils.rs"]};
createSourceSidebar();
