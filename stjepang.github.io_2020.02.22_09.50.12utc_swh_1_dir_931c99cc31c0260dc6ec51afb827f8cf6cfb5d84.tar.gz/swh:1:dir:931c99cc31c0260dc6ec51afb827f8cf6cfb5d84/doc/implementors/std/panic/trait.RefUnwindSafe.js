(function() {var implementors = {};
implementors["new_channel"] = [{text:"impl&lt;T&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/std/panic/trait.RefUnwindSafe.html\" title=\"trait std::panic::RefUnwindSafe\">RefUnwindSafe</a> for <a class=\"struct\" href=\"new_channel/struct.Sender.html\" title=\"struct new_channel::Sender\">Sender</a>&lt;T&gt;",synthetic:false,types:["new_channel::channel::Sender"]},{text:"impl&lt;T&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/std/panic/trait.RefUnwindSafe.html\" title=\"trait std::panic::RefUnwindSafe\">RefUnwindSafe</a> for <a class=\"struct\" href=\"new_channel/struct.Receiver.html\" title=\"struct new_channel::Receiver\">Receiver</a>&lt;T&gt;",synthetic:false,types:["new_channel::channel::Receiver"]},];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
