(function() {var implementors = {};
implementors["new_channel"] = [{text:"impl&lt;'a, T&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/iter/traits/collect/trait.IntoIterator.html\" title=\"trait core::iter::traits::collect::IntoIterator\">IntoIterator</a> for &amp;'a <a class=\"struct\" href=\"new_channel/struct.Receiver.html\" title=\"struct new_channel::Receiver\">Receiver</a>&lt;T&gt;",synthetic:false,types:["new_channel::channel::Receiver"]},{text:"impl&lt;T&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/iter/traits/collect/trait.IntoIterator.html\" title=\"trait core::iter::traits::collect::IntoIterator\">IntoIterator</a> for <a class=\"struct\" href=\"new_channel/struct.Receiver.html\" title=\"struct new_channel::Receiver\">Receiver</a>&lt;T&gt;",synthetic:false,types:["new_channel::channel::Receiver"]},];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
