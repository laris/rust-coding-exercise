(function() {var implementors = {};
implementors["new_channel"] = [{text:"impl&lt;'a, T&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/iter/traits/marker/trait.FusedIterator.html\" title=\"trait core::iter::traits::marker::FusedIterator\">FusedIterator</a> for <a class=\"struct\" href=\"new_channel/struct.Iter.html\" title=\"struct new_channel::Iter\">Iter</a>&lt;'a, T&gt;",synthetic:false,types:["new_channel::channel::Iter"]},{text:"impl&lt;T&gt; <a class=\"trait\" href=\"https://doc.rust-lang.org/nightly/core/iter/traits/marker/trait.FusedIterator.html\" title=\"trait core::iter::traits::marker::FusedIterator\">FusedIterator</a> for <a class=\"struct\" href=\"new_channel/struct.IntoIter.html\" title=\"struct new_channel::IntoIter\">IntoIter</a>&lt;T&gt;",synthetic:false,types:["new_channel::channel::IntoIter"]},];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
